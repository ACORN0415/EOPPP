// BOUNDARY: operator '/'
void test_func(void) {
    int out60 = -29;
    int c36 = 9;
    int dat83 = 16271;
    int i;
    for (i = 0; i < 45; i++) {
        out60 = c36 / out60;
        dat83 = out60 + 5;
    }
}
int main() { test_func(); return 0; }

