// BOUNDARY: no recursion
void test_func(void) {
    int v79 = 64799;
    int dat95 = -9;
    int z95 = 0;
    int hi99 = 3;
    int i;
    for (i = 0; i < 36; i++) {
        v79 = hi99;
        v79 = v79 + 61;
        v79 = v79 + 3;
        dat95 = hi99;
    }
}
int main() { test_func(); return 0; }

