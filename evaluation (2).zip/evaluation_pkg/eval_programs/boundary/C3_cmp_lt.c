// BOUNDARY: comparison '<'
void test_func(void) {
    int y33 = 3;
    int hi8 = 59;
    int z20 = 74;
    int i;
    for (i = 0; i < 77; i++) {
        y33 = y33 - 5;
        if (y33 < 7) {
        y33 = hi8 - z20;
        }
    }
}
int main() { test_func(); return 0; }

