// BOUNDARY: operator '-'
void test_func(void) {
    int b94 = -48;
    int lo56 = 56;
    int tmp12 = 50843;
    int lo27 = 9;
    int z52 = 39;
    int prev78 = 28;
    int i;
    for (i = 0; i < 35; i++) {
        prev78 = tmp12 - lo56;
        tmp12 = lo27 - 0;
    }
}
int main() { test_func(); return 0; }

