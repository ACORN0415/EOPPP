// BOUNDARY: comparison '!='
void test_func(void) {
    int lo84 = 96;
    int acc57 = 39;
    int c63 = 12;
    int prev90 = 31461;
    int i;
    for (i = 0; i < 45; i++) {
        acc57 = prev90 + 47;
        if (c63 != -50) {
        lo84 = acc57 + lo84;
        }
    }
}
int main() { test_func(); return 0; }

