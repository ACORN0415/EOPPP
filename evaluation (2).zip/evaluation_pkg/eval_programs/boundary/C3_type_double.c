// BOUNDARY: type 'double'
void test_func(void) {
    double x = 2.718;
    int y = 0, i;
    for (i = 0; i < 27; i++) { y = y + 1; }
}
int main() { test_func(); return 0; }

