// BOUNDARY: comparison '=='
void test_func(void) {
    int tmp39 = 2;
    int acc26 = -37;
    int b90 = 99;
    int prev53 = 63124;
    int tmp59 = -35;
    int i;
    for (i = 0; i < 70; i++) {
        tmp39 = acc26;
        if (prev53 == -1) {
        b90 = tmp39 + b90;
        }
    }
}
int main() { test_func(); return 0; }

