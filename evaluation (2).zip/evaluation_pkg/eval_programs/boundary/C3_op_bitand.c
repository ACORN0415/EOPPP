// BOUNDARY: operator '&'
void test_func(void) {
    int b53 = 60961;
    int y31 = 10;
    int v59 = 5312;
    int b81 = 43;
    int lo47 = -29;
    int a37 = -16;
    int i;
    for (i = 0; i < 50; i++) {
        b53 = lo47 & v59;
        b81 = v59 - lo47;
    }
}
int main() { test_func(); return 0; }

