// BOUNDARY: operator '+'
void test_func(void) {
    int val70 = -48;
    int cur30 = -1;
    int tmp28 = 35354;
    int dat96 = -38;
    int i;
    for (i = 0; i < 25; i++) {
        cur30 = dat96 + tmp28;
        cur30 = tmp28 + 40435;
    }
}
int main() { test_func(); return 0; }

