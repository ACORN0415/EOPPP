// BOUNDARY: for + if (not nested loop)
void test_func(void) {
    int tmp8 = 7;
    int a97 = 7;
    int val22 = 50;
    int i;
    for (i = 0; i < 59; i++) {
        tmp8 = tmp8 - 1;
        if (val22 < 4) {
        tmp8 = a97 + 25451;
        }
    }
}
int main() { test_func(); return 0; }

