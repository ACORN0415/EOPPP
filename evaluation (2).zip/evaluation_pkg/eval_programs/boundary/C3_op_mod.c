// BOUNDARY: operator '%'
void test_func(void) {
    int hi19 = 78;
    int c6 = 7;
    int prev17 = 3;
    int i;
    for (i = 0; i < 34; i++) {
        c6 = hi19 % prev17;
        c6 = c6 - 4;
    }
}
int main() { test_func(); return 0; }

