// BOUNDARY: operator '|'
void test_func(void) {
    int acc36 = -46;
    int cur6 = 85;
    int a56 = 2;
    int res74 = -1;
    int hi55 = -45;
    int i;
    for (i = 0; i < 22; i++) {
        res74 = res74 | cur6;
        cur6 = hi55 + a56;
    }
}
int main() { test_func(); return 0; }

