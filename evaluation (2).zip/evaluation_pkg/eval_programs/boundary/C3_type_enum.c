// BOUNDARY: composite type 'enum'
enum E { X, Z, B };
void test_func(void) {
    enum E e = X;
    int x = 0, i;
    for (i = 0; i < 20; i++) { x = x + 1; }
}
int main() { test_func(); return 0; }

