// BOUNDARY: operator '^'
void test_func(void) {
    int dat91 = 13;
    int res59 = 1;
    int cnt21 = 49;
    int res45 = -47;
    int prev96 = 19290;
    int val67 = 96;
    int i;
    for (i = 0; i < 35; i++) {
        dat91 = res59 ^ val67;
        res59 = cnt21 - res45;
    }
}
int main() { test_func(); return 0; }

