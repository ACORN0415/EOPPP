// BOUNDARY: 50 variables
void test_func(void) {
    int v0 = 96;
    int v1 = 18;
    int v2 = 79;
    int v3 = 41;
    int v4 = 10;
    int v5 = 67;
    int v6 = 62;
    int v7 = 59;
    int v8 = 77;
    int v9 = 93;
    int v10 = 34;
    int v11 = 8;
    int v12 = 57;
    int v13 = 49;
    int v14 = 99;
    int v15 = 24;
    int v16 = 98;
    int v17 = 35;
    int v18 = 91;
    int v19 = 18;
    int v20 = 46;
    int v21 = 99;
    int v22 = 7;
    int v23 = 60;
    int v24 = 31;
    int v25 = 28;
    int v26 = 81;
    int v27 = 0;
    int v28 = 41;
    int v29 = 45;
    int v30 = 79;
    int v31 = 61;
    int v32 = 71;
    int v33 = 18;
    int v34 = 100;
    int v35 = 34;
    int v36 = 40;
    int v37 = 62;
    int v38 = 40;
    int v39 = 77;
    int v40 = 68;
    int v41 = 25;
    int v42 = 82;
    int v43 = 24;
    int v44 = 76;
    int v45 = 77;
    int v46 = 15;
    int v47 = 37;
    int v48 = 93;
    int v49 = 7;
    int i;
    for (i = 0; i < 10; i++) {
        v16 = v6 + v16;
        v12 = v9 + v7;
        v9 = v13 + v0;
        v4 = v8 + v6;
    }
}
int main() { test_func(); return 0; }

