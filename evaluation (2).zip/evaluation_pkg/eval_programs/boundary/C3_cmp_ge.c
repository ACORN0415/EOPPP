// BOUNDARY: comparison '>='
void test_func(void) {
    int y74 = 63;
    int z5 = 79;
    int x24 = -42;
    int i;
    for (i = 0; i < 75; i++) {
        y74 = x24 - y74;
        if (y74 >= 50) {
        z5 = x24 - 66;
        }
    }
}
int main() { test_func(); return 0; }

