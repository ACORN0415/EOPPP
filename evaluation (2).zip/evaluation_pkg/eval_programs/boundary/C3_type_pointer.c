// BOUNDARY: pointer type
void test_func(void) {
    int x = 58;
    int *p = &x;
    int i;
    for (i = 0; i < 30; i++) { *p = *p + 1; }
}
int main() { test_func(); return 0; }

