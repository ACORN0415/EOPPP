// BOUNDARY: operator '*'
void test_func(void) {
    int dat44 = 5;
    int x62 = -4;
    int cnt92 = 2;
    int x49 = 6;
    int cur48 = 79;
    int lo54 = 17;
    int i;
    for (i = 0; i < 28; i++) {
        cnt92 = x62 * x49;
        x62 = x49 - 2;
    }
}
int main() { test_func(); return 0; }

