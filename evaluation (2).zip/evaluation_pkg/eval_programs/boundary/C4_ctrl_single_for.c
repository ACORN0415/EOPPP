// BOUNDARY: single for loop
void test_func(void) {
    int tmp50 = 0;
    int x55 = 8;
    int tmp57 = 7;
    int x67 = -1;
    int tmp5 = 1863;
    int i;
    for (i = 0; i < 20; i++) {
        x55 = tmp50 + tmp5;
        tmp57 = tmp57 - -30;
        tmp57 = tmp57 - tmp5;
        tmp5 = tmp50 + tmp50;
    }
}
int main() { test_func(); return 0; }

