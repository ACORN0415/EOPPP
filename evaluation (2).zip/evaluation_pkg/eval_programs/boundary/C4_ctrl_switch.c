// BOUNDARY: switch-case
void test_func(void) {
    int x = 0, y = 0, i;
    for (i = 0; i < 31; i++) {
        switch (x) {
            case 0: y = y + 7; break;
            case 1: y = y + 2; break;
            case 2: y = y + 9; break;
            default: y = y + 1; break;
        }
        x = x + 1;
    }
}
int main() { test_func(); return 0; }

