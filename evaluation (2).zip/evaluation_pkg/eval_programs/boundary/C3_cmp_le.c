// BOUNDARY: comparison '<='
void test_func(void) {
    int c43 = 5;
    int c76 = -40;
    int cnt30 = 4;
    int sum31 = 0;
    int i;
    for (i = 0; i < 27; i++) {
        cnt30 = cnt30;
        if (c43 <= -40) {
        c76 = cnt30;
        }
    }
}
int main() { test_func(); return 0; }

