// BOUNDARY: comparison '>'
void test_func(void) {
    int prev6 = 32603;
    int b71 = 47579;
    int val13 = 73;
    int dat38 = 1;
    int sum63 = 53206;
    int i;
    for (i = 0; i < 29; i++) {
        dat38 = prev6 - val13;
        if (prev6 > 28) {
        b71 = dat38 + sum63;
        }
    }
}
int main() { test_func(); return 0; }

