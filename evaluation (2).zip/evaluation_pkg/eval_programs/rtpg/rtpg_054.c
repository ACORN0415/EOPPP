// RTPG_54: vars=5 stmts=3
int xn[16];
int yo[16];
void test_func(void) {
    int b75 = -44;
    int x18 = 2;
    int sum62 = 5857;
    int cur39 = 40;
    int cur38 = 10;
    int i;
    for (i = 0; i < 16; i++) {
        cur38 = xn[i];
        cur39 = cur39 - x18;
        b75 = b75 - 4;
        x18 = sum62 - b75;
        yo[i] = sum62;
    }
}
int main() { test_func(); return 0; }

