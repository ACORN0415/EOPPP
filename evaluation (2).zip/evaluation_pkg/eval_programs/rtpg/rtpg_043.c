// RTPG_43: vars=3 stmts=2
void test_func(void) {
    int z49 = 6;
    int acc67 = 95;
    int y37 = 47919;
    int i;
    for (i = 0; i < 7; i++) {
        int j;
        for (j = 0; j < 6; j++) {
        acc67 = z49;
        y37 = y37 + 5;
        }
    }
}
int main() { test_func(); return 0; }

