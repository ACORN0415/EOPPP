// RTPG_45: vars=36 stmts=3
void test_func(void) {
    int dat7 = 3;
    int c62 = 22;
    int hi15 = 10;
    int hi88 = 8;
    int sum53 = 48892;
    int val20 = -7;
    int sum70 = 2;
    int val46 = 8;
    int cur74 = 45;
    int cur6 = 6;
    int hi72 = -47;
    int res81 = 19;
    int dat2 = 10303;
    int val63 = 63473;
    int res93 = 0;
    int b40 = 7;
    int cnt81 = 4;
    int tmp3 = -24;
    int z65 = -6;
    int hi5 = 24;
    int sum37 = 8;
    int c6 = 24;
    int x0 = 3;
    int a97 = 91;
    int a47 = -27;
    int sum81 = -2;
    int b33 = 6;
    int sum63 = 17815;
    int lo88 = 5;
    int c48 = 15;
    int sum74 = 40896;
    int lo28 = 38089;
    int z76 = -42;
    int b45 = 13786;
    int cnt33 = 7;
    int out94 = 0;
    int i;
    for (i = 0; i < 31; i++) {
        sum53 = dat2;
        c6 = sum81 + 93;
        tmp3 = x0 - sum74;
        if (z76 <= -13) {
        c48 = val46 - lo28;
        }
    }
done:
    lo28 = 0;
}
int main() { test_func(); return 0; }

