// RTPG_52: vars=11 stmts=4
void test_func(void) {
    int c25 = -17;
    int c79 = 44268;
    int cnt63 = 29;
    int y2 = 7;
    int hi16 = 8;
    int sum30 = 7;
    int v36 = 9;
    int hi12 = 16;
    int c77 = 57871;
    int z85 = 83;
    int v71 = 57555;
    int i;
    for (i = 0; i < 61; i++) {
        c25 = hi12 - 22;
        sum30 = sum30 + y2;
        c77 = y2 - cnt63;
        v36 = hi12 - c77;
        if (c25 >= -13) {
        c25 = c25 + 1;
        }
    }
}
int main() { test_func(); return 0; }

