// RTPG_60: vars=7 stmts=3
void test_func(void) {
    int v95 = 4;
    double dat99 = 52.50;
    int dat39 = -29;
    int val95 = 14450;
    int cur18 = -27;
    int z13 = 3;
    int cnt96 = 11234;
    int i;
    for (i = 0; i < 6; i++) {
        cur18 = v95 / dat39;
        v95 = val95 / z13;
        cnt96 = cnt96 & v95;
        if (v95 < 4) {
        cur18 = val95 - val95;
        }
    }
}
int main() { test_func(); return 0; }

