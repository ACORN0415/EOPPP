// RTPG_48: vars=26 stmts=4
void test_func(void) {
    int cur59 = 4;
    int y10 = 6;
    int c34 = 65;
    int out22 = 31;
    int c32 = 24;
    int y92 = -23;
    int res25 = 57;
    int val36 = 9;
    int tmp14 = 19;
    int cnt40 = 47579;
    int b24 = 5;
    int acc77 = 33;
    int sum59 = 39;
    int sum55 = 2;
    int b3 = 97;
    int b30 = 41574;
    int z81 = 64448;
    int x31 = 6;
    int y25 = 34;
    int val35 = 42831;
    int v52 = 24084;
    int tmp51 = -33;
    int hi2 = 10;
    int hi71 = 17052;
    int cnt54 = 62;
    int b95 = 76;
    int h0 = 23841;
    int sv0 = 0;
    int h1 = 6;
    int sv1 = 0;
    int i;
    for (i = 0; i < 7; i++) {
        v52 = v52 + 1;
        res25 = hi2;
        y10 = val35 - sum55;
        acc77 = y92 * 57038;
    }
}
int main() { test_func(); return 0; }

