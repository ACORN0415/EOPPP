// RTPG_61: vars=10 stmts=4
void test_func(void) {
    int lo79 = 56088;
    int acc86 = 13;
    int cur5 = 9;
    int tmp47 = 39499;
    int acc2 = 7;
    int hi51 = 3;
    int hi65 = 4;
    int lo29 = 36;
    int cnt84 = 10;
    int v0 = 8;
    int i;
    for (i = 0; i < 35; i++) {
        hi51 = v0 + 50024;
        tmp47 = acc2 + 15;
        v0 = acc86 - 49;
        lo79 = lo79 + 4;
        if (hi65 <= 43) {
        cur5 = cur5 + 1;
        }
    }
}
int main() { test_func(); return 0; }

