// RTPG_97: vars=9 stmts=5
int xn[32];
int yo[32];
void test_func(void) {
    int acc70 = 23635;
    int c84 = 38;
    int cnt6 = 20429;
    int hi13 = 19751;
    int sum27 = 17113;
    int lo38 = 5;
    int prev18 = 1;
    int v27 = -39;
    int out83 = 40;
    int h0 = 58;
    int sv0 = 0;
    int h1 = -13;
    int sv1 = 0;
    int h2 = 15525;
    int sv2 = 0;
    int h3 = 71;
    int sv3 = 0;
    int i;
    for (i = 0; i < 32; i++) {
        hi13 = xn[i];
        cnt6 = c84 + acc70;
        v27 = v27 + cnt6;
        lo38 = cnt6 + v27;
        lo38 = c84;
        c84 = cnt6 - 0;
        yo[i] = lo38;
    }
}
int main() { test_func(); return 0; }

