// RTPG_88: vars=11 stmts=5
int xn[32];
int yo[32];
void test_func(void) {
    int prev28 = 5;
    int val40 = 3;
    int prev63 = 10553;
    int c51 = 21819;
    int sum0 = -48;
    int lo20 = 8;
    int acc64 = 3;
    int lo36 = 23;
    int out68 = 7;
    int cur80 = 5;
    float a85 = 68.20;
    int i;
    for (i = 0; i < 32; i++) {
        acc64 = xn[i];
        out68 = acc64 - val40;
        sum0 = sum0 + 5;
        a85 = a85 + 4;
        lo36 = sum0 - prev28;
        lo20 = out68 - lo36;
        if (val40 < -13) {
        sum0 = sum0 + 2;
        }
        yo[i] = lo20;
    }
}
int main() { test_func(); return 0; }

