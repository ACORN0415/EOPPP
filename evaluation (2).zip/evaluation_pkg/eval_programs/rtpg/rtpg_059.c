// RTPG_59: vars=11 stmts=3
int idx_arr[64];
void test_func(void) {
    int b11 = 58;
    int c75 = 52199;
    int z54 = 55404;
    int out26 = 49994;
    int b26 = 47;
    int tmp38 = 40089;
    int v31 = 4;
    int cnt22 = -33;
    int tmp64 = 1;
    int c92 = 54;
    int lo39 = 9337;
    int i;
    for (i = 0; i < 31; i++) {
        b11 = xn[idx_arr[i]];
        c75 = c92 + z54;
        v31 = tmp38;
        tmp64 = lo39 + tmp38;
        if (lo39 >= 58) {
        out26 = cnt22 + 30;
        }
    }
}
int main() { test_func(); return 0; }

