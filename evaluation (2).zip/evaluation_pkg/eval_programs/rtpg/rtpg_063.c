// RTPG_63: vars=3 stmts=12
void test_func(void) {
    int out68 = 12;
    int x50 = 10;
    int c51 = 8;
    int i;
    for (i = 0; i < 70; i++) {
        int j;
        for (j = 0; j < 9; j++) {
        c51 = c51 + 1;
        out68 = out68 - 3;
        c51 = x50 + 38457;
        out68 = out68 - 3;
        c51 = c51;
        c51 = c51 + 1;
        c51 = out68 + out68;
        out68 = out68;
        out68 = out68 + 5;
        x50 = out68;
        c51 = c51 - 1;
        c51 = x50;
        }
    }
}
int main() { test_func(); return 0; }

