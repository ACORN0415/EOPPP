// RTPG_91: vars=12 stmts=9
void test_func(void) {
    int lo67 = 4;
    int c82 = 42811;
    int x28 = 35;
    int cnt35 = 19;
    int dat43 = -38;
    int sum0 = 9;
    int b83 = 27;
    int prev73 = 4;
    int cnt2 = 5;
    int prev2 = 27340;
    int lo57 = 7;
    int acc9 = 3;
    int *ptr = &x28;
    int i;
    for (i = 0; i < 41; i++) {
        cnt2 = cnt2 + 2;
        cnt35 = prev73 - acc9;
        sum0 = cnt35 + acc9;
        cnt2 = prev73;
        dat43 = dat43 + 4;
        lo67 = b83 - b83;
        c82 = sum0;
        dat43 = b83 - cnt35;
        acc9 = lo57 - prev73;
        *ptr = *ptr + 1;
    }
}
int main() { test_func(); return 0; }

