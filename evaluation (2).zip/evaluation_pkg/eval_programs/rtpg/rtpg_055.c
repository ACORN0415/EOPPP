// RTPG_55: vars=20 stmts=6
int idx_arr[32];
void test_func(void) {
    int z68 = 50;
    int c32 = 33808;
    int x91 = -44;
    int sum18 = 7;
    int dat5 = 60926;
    int c7 = 11;
    int z19 = -16;
    int acc23 = 39927;
    int v31 = -40;
    int acc48 = 32134;
    int c53 = 132;
    int val11 = 9;
    int hi2 = 32885;
    int acc55 = 5;
    int acc51 = 69;
    int dat56 = 0;
    int sum52 = 56;
    int out21 = 34258;
    int a12 = 85;
    int x67 = 3;
    int h0 = 2;
    int sv0 = 0;
    int h1 = 54155;
    int sv1 = 0;
    int h2 = 6;
    int sv2 = 0;
    int h3 = 87;
    int sv3 = 0;
    int i;
    for (i = 0; i < 76; i++) {
        hi2 = xn[idx_arr[i]];
        val11 = c7 + z68;
        z19 = z68 + acc23;
        val11 = x91 - 3;
        x67 = z19 * 0;
        a12 = a12 - 2;
        a12 = a12 + 1;
    }
}
int main() { test_func(); return 0; }

