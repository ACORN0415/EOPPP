// RTPG_51: vars=3 stmts=9
#include <stdlib.h>
void test_func(void) {
    int v3 = 31691;
    int v61 = 25;
    int x89 = 7;
    int *darr = (int *)malloc(32 * sizeof(int));
    int i;
    for (i = 0; i < 63; i++) {
        v3 = x89 - 10;
        v3 = x89;
        v61 = v61 + v3;
        x89 = v61 - x89;
        v3 = v61 - x89;
        v3 = x89 + v61;
        x89 = x89;
        v3 = x89;
        v61 = v3 - v61;
        darr[i] = v61;
    }
    free(darr);
}
int main() { test_func(); return 0; }

