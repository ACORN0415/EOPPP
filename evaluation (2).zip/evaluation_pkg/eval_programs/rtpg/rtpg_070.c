// RTPG_70: vars=10 stmts=6
void test_func(void) {
    int tmp89 = -37;
    int out1 = 29236;
    int y79 = 45736;
    int b56 = 7;
    int cur65 = 14202;
    int cnt64 = 6;
    int y94 = -7;
    int lo33 = 7;
    int acc47 = -31;
    int z87 = 5;
    int i;
    for (i = 0; i < 51; i++) {
        cnt64 = lo33 + b56;
        cur65 = tmp89 ^ y94;
        out1 = out1 - 59169;
        cur65 = tmp89 + -7;
        acc47 = y94 | lo33;
        y79 = cnt64 + y94;
    }
}
int main() { test_func(); return 0; }

