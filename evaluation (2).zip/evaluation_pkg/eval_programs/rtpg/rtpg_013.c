// RTPG_13: vars=53 stmts=6
int xn[32];
int yo[32];
void test_func(void) {
    int hi36 = 66;
    int res59 = 7;
    int dat92 = 3493;
    int a6 = 4;
    int out1 = 11;
    int res58 = -19;
    int b25 = 6;
    int out13 = 53789;
    int acc24 = 18;
    int sum9 = 68;
    int cnt31 = 69;
    int cur65 = 34651;
    int y72 = -19;
    int dat45 = 27169;
    int out46 = 45;
    int cur97 = 49768;
    int y4 = 5;
    int b91 = 45399;
    int tmp18 = -18;
    int val57 = 18;
    int out35 = 28;
    int cur70 = 35;
    int b77 = 43293;
    int res5 = 1;
    int prev46 = 62351;
    int hi39 = 97;
    int lo15 = 32;
    int res51 = 44;
    int prev78 = 52035;
    int sum75 = 2;
    int tmp27 = 78;
    int res17 = 8;
    int acc78 = 8;
    int prev16 = 94;
    int out24 = 95;
    int y6 = 36;
    int c63 = 52;
    int a55 = 1;
    int acc20 = 2;
    int a16 = 31;
    int sum63 = 75;
    int b33 = 10;
    int prev64 = -35;
    int cur43 = 6;
    int z50 = -13;
    int hi2 = 20;
    int c41 = 39;
    int acc30 = 10731;
    int acc60 = 8;
    int y51 = 20;
    int a50 = 2;
    int lo97 = 10;
    int sum49 = 7;
    int i;
    for (i = 0; i < 87; i++) {
        int j;
        for (j = 0; j < 18; j++) {
        sum75 = sum75 + 5;
        sum75 = c41;
        res59 = y4 + sum49;
        acc30 = a55 + 0;
        out1 = dat92 - tmp18;
        cur65 = y51 - 49480;
        }
    }
}
int main() { test_func(); return 0; }

