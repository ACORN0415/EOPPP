// RTPG_39: vars=9 stmts=5
void test_func(void) {
    int out99 = 59;
    int hi80 = -5;
    int z31 = 77;
    int sum78 = 0;
    int z66 = 95;
    int y43 = 17;
    int out74 = 79;
    int lo66 = -49;
    int z87 = 20;
    int i;
    for (i = 0; i < 96; i++) {
        z31 = sum78;
        lo66 = z87 + 20205;
        out74 = sum78 + lo66;
        sum78 = sum78 - 1;
        z66 = out99 + lo66;
        if (out74 >= 27) {
        lo66 = lo66 + 4;
        }
    }
}
int main() { test_func(); return 0; }

