// RTPG_80: vars=9 stmts=6
int xn[16];
int yo[16];
void test_func(void) {
    int b66 = 7;
    int tmp89 = 5;
    int b4 = 9;
    int tmp39 = 4;
    int z26 = -1;
    int out26 = 3;
    int hi35 = 10;
    int cur52 = 46;
    int a47 = 56896;
    int i;
    for (i = 0; i < 16; i++) {
        b66 = xn[i];
        tmp89 = tmp89 - 3;
        a47 = hi35 + z26;
        hi35 = tmp39 + b4;
        z26 = tmp89;
        tmp39 = tmp39 - 3;
        hi35 = z26 - z26;
        yo[i] = z26;
    }
}
int main() { test_func(); return 0; }

