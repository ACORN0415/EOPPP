// RTPG_8: vars=7 stmts=8
int xn[64];
int yo[64];
void test_func(void) {
    int c34 = 7;
    int z28 = 30904;
    int res15 = 29;
    int a91 = 41;
    int sum10 = -46;
    int lo65 = 7;
    int b55 = 19598;
    int i;
    for (i = 0; i < 64; i++) {
        c34 = xn[i];
        b55 = z28;
        res15 = c34 + a91;
        lo65 = lo65 - 1;
        c34 = sum10 + b55;
        lo65 = lo65 + 2;
        res15 = c34 - sum10;
        z28 = z28 - 2;
        lo65 = sum10 - c34;
        yo[i] = sum10;
    }
}
int main() { test_func(); return 0; }

