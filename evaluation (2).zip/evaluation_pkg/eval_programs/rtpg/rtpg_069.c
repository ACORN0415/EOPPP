// RTPG_69: vars=6 stmts=2
int xn[32];
int yo[32];
void test_func(void) {
    int acc96 = 8;
    int a42 = 62;
    int prev92 = 2;
    int res24 = -39;
    int cnt94 = 19;
    int cur16 = 17;
    int *ptr = &prev92;
    int i;
    for (i = 0; i < 44; i++) {
        switch (cnt94) {
            case 0: acc96 = 10; break;
            case 1: a42 = 9; break;
            case 2: a42 = 4; break;
            default: break;
        }
        cnt94 = cnt94 + 1;
    }
}
int main() { test_func(); return 0; }

