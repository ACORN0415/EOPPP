// RTPG_31: vars=43 stmts=10
void test_func(void) {
    int c46 = 9;
    int acc58 = 158;
    int cnt19 = 5694;
    int dat18 = 99;
    int b73 = 12808;
    int b56 = 2;
    int c29 = 70;
    int b74 = 3;
    int c28 = 49;
    int val27 = 20288;
    int c82 = 34250;
    int dat20 = 36119;
    int res5 = 2;
    int dat8 = 72;
    int cnt2 = 23;
    int x92 = 30117;
    int a22 = 28;
    int res51 = 28;
    int tmp53 = 31;
    int res87 = 7;
    int c79 = 4;
    int v75 = 6;
    int prev16 = 2;
    int b80 = 34;
    int val23 = 50;
    int z65 = 10;
    int dat81 = 36;
    int acc92 = 10;
    int sum10 = 71;
    int res33 = 25497;
    int tmp48 = 23;
    int v57 = 14;
    int hi78 = 66;
    int hi61 = -2;
    int y21 = 5;
    int a84 = 8855;
    int cnt76 = 29;
    int a2 = 67;
    int a61 = 12;
    int c92 = 23;
    int b23 = -23;
    int v66 = -26;
    int tmp5 = -17;
    int i;
    for (i = 0; i < 77; i++) {
        x92 = x92 - 2;
        c29 = b56 - c92;
        c46 = c46 + 4;
        b80 = b80 - 4;
        cnt76 = v57;
        dat20 = dat20 - 4;
        cnt2 = cnt2 + 1;
        hi61 = tmp48 + y21;
        hi78 = z65;
        dat20 = b74 - hi61;
    }
}
int main() { test_func(); return 0; }

