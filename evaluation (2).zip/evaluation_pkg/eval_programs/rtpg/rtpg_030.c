// RTPG_30: vars=4 stmts=3
int idx_arr[64];
void test_func(void) {
    int sum17 = 11870;
    int dat93 = 14;
    int b46 = -33;
    int prev28 = 19163;
    int i;
    for (i = 0; i < 38; i++) {
        b46 = xn[idx_arr[i]];
        sum17 = prev28 + 1;
        dat93 = dat93 - 4;
        prev28 = sum17 - prev28;
    }
}
int main() { test_func(); return 0; }

