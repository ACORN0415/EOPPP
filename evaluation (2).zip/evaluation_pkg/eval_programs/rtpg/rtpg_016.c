// RTPG_16: vars=10 stmts=8
void test_func(void) {
    int v75 = 6;
    int y22 = 8;
    int acc2 = 44643;
    int prev9 = 35826;
    int sum20 = 49208;
    int dat84 = 2;
    int dat30 = 9;
    int dat49 = 20222;
    int b96 = 5;
    int out42 = 4;
    int i;
    for (i = 0; i < 60; i++) {
        acc2 = acc2 - dat49;
        b96 = b96 - 1;
        v75 = dat84 + out42;
        out42 = dat30;
        v75 = dat30;
        dat30 = b96 + out42;
        b96 = dat30 + 35181;
        acc2 = acc2 - sum20;
    }
}
int main() { test_func(); return 0; }

