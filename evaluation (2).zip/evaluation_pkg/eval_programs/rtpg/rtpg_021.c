// RTPG_21: vars=9 stmts=4
void test_func(void) {
    int y27 = 46628;
    int sum90 = 87;
    int cnt15 = -47;
    int val15 = 1;
    int out45 = -43;
    int sum59 = 48;
    int z20 = 25920;
    int acc18 = 2;
    int v57 = 56775;
    int i;
    for (i = 0; i < 35; i++) {
        acc18 = z20 - cnt15;
        sum59 = cnt15 - 7;
        out45 = z20 + acc18;
        sum90 = z20;
        if (cnt15 >= 1) {
        v57 = v57 + 47070;
        }
    }
}
int main() { test_func(); return 0; }

