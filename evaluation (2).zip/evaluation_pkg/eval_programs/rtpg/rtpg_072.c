// RTPG_72: vars=23 stmts=4
void test_func(void) {
    int lo70 = 40292;
    int hi95 = 0;
    double x78 = 84.08;
    int lo52 = 22337;
    double a44 = 19.27;
    int out76 = 16892;
    int v28 = 20768;
    float cur28 = 50.43;
    int out12 = 47;
    int prev0 = 3361;
    float sum53 = 2.78;
    int lo64 = 23;
    int dat4 = 30;
    float v60 = 29.69;
    int cnt81 = 100;
    int cur22 = 4;
    float prev14 = 10.71;
    int cnt13 = 10;
    int sum84 = 3;
    int a11 = 27564;
    int sum89 = 31;
    int c69 = 2;
    int cnt48 = 11;
    int i;
    for (i = 0; i < 51; i++) {
        prev14 = lo52;
        v28 = v28 + 5;
        lo70 = lo70 + 2;
        lo64 = v28 + sum53;
    }
}
int main() { test_func(); return 0; }

