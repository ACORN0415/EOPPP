// RTPG_78: vars=21 stmts=3
#include <stdlib.h>
void test_func(void) {
    int dat43 = 61;
    int a72 = 45626;
    int cur64 = -45;
    int cur90 = 65462;
    int y82 = 5;
    int lo92 = 2;
    int c83 = 0;
    int res8 = 1;
    int lo5 = 58919;
    int cur17 = 31;
    int res26 = 12;
    int res49 = 44;
    int lo91 = 24;
    int b35 = 47129;
    int x20 = 19;
    int z82 = 43;
    int prev1 = 61;
    int lo35 = 8803;
    int b45 = 6;
    int sum50 = 2;
    int dat38 = 30;
    int *darr = (int *)malloc(32 * sizeof(int));
    int i;
    for (i = 0; i < 70; i++) {
        res8 = lo5;
        lo91 = cur64;
        lo92 = cur64;
        darr[i] = lo35;
        if (b45 > 82) {
        sum50 = sum50 - 4;
        }
    }
    free(darr);
}
int main() { test_func(); return 0; }

