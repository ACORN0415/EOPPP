// RTPG_67: vars=6 stmts=7
int xn[32];
int yo[32];
int idx_arr[32];
void test_func(void) {
    int lo28 = -16;
    int out26 = 94;
    int val80 = 11;
    int prev83 = 24755;
    int dat13 = 37;
    int x68 = 2;
    int i;
    for (i = 0; i < 32; i++) {
        out26 = xn[i];
        lo28 = xn[idx_arr[i]];
        prev83 = prev83 - 1;
        dat13 = prev83 - lo28;
        lo28 = x68 + out26;
        out26 = val80 + x68;
        dat13 = lo28 + dat13;
        x68 = x68;
        lo28 = out26 - 21;
        yo[i] = prev83;
    }
}
int main() { test_func(); return 0; }

