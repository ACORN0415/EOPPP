// RTPG_27: vars=6 stmts=7
void test_func(void) {
    int b53 = 93;
    int x38 = 50;
    int b26 = -25;
    int a84 = 40;
    int res34 = 27223;
    int cnt84 = 5;
    int *ptr = &b53;
    int i;
    for (i = 0; i < 88; i++) {
        switch (res34) {
            case 0: a84 = 2; break;
            case 1: b26 = 59; break;
            case 2: a84 = 23; break;
            case 3: b26 = 10; break;
            default: break;
        }
        res34 = res34 + 1;
    }
}
int main() { test_func(); return 0; }

