// RTPG_22: vars=10 stmts=3
int xn[64];
int yo[64];
void test_func(void) {
    int y97 = -26;
    int tmp73 = -46;
    int tmp75 = 9;
    int cur72 = 26;
    int prev45 = -9;
    int dat18 = 19;
    int x90 = 1;
    int c22 = -12;
    int acc94 = 31;
    int cur75 = 38;
    int i;
    for (i = 0; i < 64; i++) {
        cur75 = xn[i];
        tmp75 = prev45 + cur75;
        tmp75 = cur75 - cur75;
        y97 = cur75 - 13646;
        yo[i] = tmp75;
    }
}
int main() { test_func(); return 0; }

