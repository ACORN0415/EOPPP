// RTPG_81: vars=17 stmts=8
void test_func(void) {
    int y23 = 6;
    int tmp44 = 48675;
    int y70 = 32;
    int hi16 = 78;
    int a83 = 48;
    int val32 = 9;
    int c18 = 4;
    int tmp80 = -23;
    int y29 = 19671;
    int tmp7 = 29437;
    int y76 = 6742;
    int cur69 = 67;
    int a9 = -26;
    int x86 = -19;
    int res56 = -10;
    int val33 = 7;
    int dat40 = 65;
    int *ptr = &val33;
    int h0 = 7;
    int sv0 = 0;
    int h1 = -19;
    int sv1 = 0;
    int h2 = 37;
    int sv2 = 0;
    int h3 = -40;
    int sv3 = 0;
    int i;
    for (i = 0; i < 27; i++) {
        c18 = res56 + 34522;
        tmp44 = x86 * 38;
        a9 = cur69 - a83;
        tmp7 = hi16 * 5;
        res56 = cur69 | res56;
        val33 = val32 + 48481;
        dat40 = dat40 - 1;
        dat40 = val33 / y76;
        *ptr = *ptr + 5;
        if (dat40 >= 23) {
        y76 = y76 + val32;
        }
    }
}
int main() { test_func(); return 0; }

