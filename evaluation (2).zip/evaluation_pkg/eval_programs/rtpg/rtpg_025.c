// RTPG_25: vars=6 stmts=6
void test_func(void) {
    int x28 = 36095;
    int val77 = -6;
    int b82 = 7;
    int c76 = 85;
    int res2 = 4;
    int x60 = 82;
    int i;
    for (i = 0; i < 75; i++) {
        val77 = x60 ^ x60;
        c76 = val77 & x28;
        x60 = x60 + 34004;
        x60 = res2 + b82;
        val77 = val77 - 3;
        val77 = val77 + 3;
    }
}
int main() { test_func(); return 0; }

