// RTPG_3: vars=8 stmts=5
int idx_arr[32];
void test_func(void) {
    int cnt62 = 35;
    int prev53 = 3535;
    int tmp34 = 9;
    int sum96 = 4;
    int tmp62 = -17;
    int x49 = 44;
    int out77 = 6;
    int out95 = 8;
    int i;
    for (i = 0; i < 93; i++) {
        int j;
        for (j = 0; j < 6; j++) {
        cnt62 = sum96 + 16545;
        prev53 = prev53 + 4;
        tmp62 = tmp34;
        prev53 = tmp62 + 49193;
        sum96 = sum96 + tmp62;
        }
    }
}
int main() { test_func(); return 0; }

