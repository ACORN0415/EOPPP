// RTPG_15: vars=9 stmts=5
void test_func(void) {
    int hi31 = 12925;
    int v24 = 41016;
    float sum48 = 74.13;
    double tmp70 = 29.52;
    float lo68 = 37.98;
    int acc99 = 84;
    int v50 = 64304;
    double cur39 = 16.93;
    int a95 = 7;
    int h0 = 837;
    int sv0 = 0;
    int h1 = 30;
    int sv1 = 0;
    int i;
    for (i = 0; i < 52; i++) {
        a95 = cur39 * 63335;
        a95 = a95 * 3;
        v50 = sum48 * -38;
        a95 = lo68 * 51;
        cur39 = cur39 + 2;
        if (lo68 != -30) {
        hi31 = v50 - v50;
        }
    }
}
int main() { test_func(); return 0; }

