// RTPG_75: vars=10 stmts=6
int idx_arr[16];
void test_func(void) {
    int hi31 = 37;
    int y2 = 13;
    int acc2 = 63;
    int hi54 = 47749;
    int cur60 = 43744;
    int hi14 = -16;
    int dat0 = 85;
    int c33 = 32;
    int x76 = 25408;
    int z21 = -37;
    int h0 = 51253;
    int sv0 = 0;
    int h1 = 25;
    int sv1 = 0;
    int h2 = 56;
    int sv2 = 0;
    int i;
    for (i = 0; i < 95; i++) {
        cur60 = xn[idx_arr[i]];
        hi31 = c33 * 60;
        acc2 = c33;
        cur60 = hi31 * 7;
        cur60 = hi31 * 6;
        hi14 = cur60 * 8;
        acc2 = dat0 + 5;
    }
}
int main() { test_func(); return 0; }

