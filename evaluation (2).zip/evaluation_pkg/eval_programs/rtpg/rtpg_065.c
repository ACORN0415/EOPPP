// RTPG_65: vars=10 stmts=11
#include <stdlib.h>
void test_func(void) {
    int b98 = 48;
    int hi25 = 6;
    int cur1 = 34;
    int c51 = 56;
    int cnt15 = 3;
    int res19 = 2;
    int val28 = 26;
    int a55 = 3;
    int z67 = 52413;
    int hi0 = -36;
    int *darr = (int *)malloc(32 * sizeof(int));
    int i;
    for (i = 0; i < 55; i++) {
        int j;
        for (j = 0; j < 16; j++) {
        z67 = c51 + res19;
        val28 = val28 + 4;
        a55 = cnt15;
        a55 = val28 + hi0;
        cur1 = cur1 + 2;
        cnt15 = cnt15 + val28;
        c51 = hi25 + z67;
        c51 = c51 + 2;
        hi25 = val28 + 4;
        hi0 = hi25 + 2;
        c51 = val28;
        }
    }
    free(darr);
}
int main() { test_func(); return 0; }

