// RTPG_90: vars=3 stmts=5
int xn[16];
int yo[16];
void test_func(void) {
    int c41 = 51127;
    double z31 = 5.93;
    double hi92 = 27.60;
    int h0 = -14;
    int sv0 = 0;
    int h1 = -9;
    int sv1 = 0;
    int i;
    for (i = 0; i < 16; i++) {
        c41 = xn[i];
        hi92 = hi92 + 42;
        c41 = hi92 - z31;
        z31 = c41 - 59;
        hi92 = z31 * 27;
        z31 = z31 * 7;
        yo[i] = c41;
    }
}
int main() { test_func(); return 0; }

