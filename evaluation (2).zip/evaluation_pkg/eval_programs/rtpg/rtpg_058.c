// RTPG_58: vars=49 stmts=10
struct Node { int a; int b; };
void test_func(void) {
    int z40 = -47;
    int sum95 = 2;
    int acc32 = 55800;
    int acc54 = 8;
    int b50 = 51235;
    int val24 = 0;
    int z37 = 43;
    int x98 = 1;
    int out33 = 12;
    int cur29 = -1;
    int b96 = 9173;
    int dat5 = -3;
    int lo92 = 5;
    int dat20 = 2;
    int c56 = 17;
    int tmp33 = 40;
    int v60 = 26605;
    int out10 = 18703;
    int a9 = 78;
    int cur51 = 9;
    int tmp29 = 83;
    int v39 = 22955;
    int out82 = 56634;
    int lo57 = 12522;
    int dat70 = 21;
    int out25 = 28477;
    int res97 = 71;
    int cur32 = 42732;
    int lo43 = 7;
    int x60 = 60543;
    int tmp66 = 25481;
    int res65 = -49;
    int prev3 = 60850;
    int v54 = 31758;
    int cur63 = 10;
    int cur4 = 13;
    int z45 = 18;
    int tmp12 = 98;
    int cnt26 = 6;
    int lo65 = 28334;
    int lo59 = 13474;
    int cnt48 = 4;
    int cnt52 = 26;
    int acc34 = 2103;
    int sum36 = 0;
    int acc25 = -38;
    int lo66 = 66;
    int prev74 = 21;
    int z35 = 0;
    struct Node s; s.a = -37; s.b = 0;
    int i;
    for (i = 0; i < 52; i++) {
        dat70 = x60 + 1;
        b50 = res97 - 14;
        z37 = z37 - 4;
        acc34 = v39 + 41677;
        b50 = sum95;
        cnt26 = cnt26 - 4;
        prev3 = prev3 + 79;
        tmp33 = z35 + tmp33;
        acc54 = lo57 - -25;
        cnt48 = tmp33 - prev74;
        s.a = s.a + s.b;
        if (v39 > 21) {
        tmp29 = v54 - cnt48;
        }
    }
}
int main() { test_func(); return 0; }

