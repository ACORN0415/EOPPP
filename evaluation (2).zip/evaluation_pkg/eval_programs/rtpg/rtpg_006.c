// RTPG_6: vars=3 stmts=3
int xn[64];
int yo[64];
void test_func(void) {
    int a83 = 44425;
    int out92 = 94;
    int v55 = 86;
    int i;
    for (i = 0; i < 64; i++) {
        a83 = xn[i];
        v55 = a83 + v55;
        a83 = a83 + out92;
        v55 = v55 - v55;
        if (a83 >= 40) {
        v55 = v55 - a83;
        }
        yo[i] = v55;
    }
}
int main() { test_func(); return 0; }

