// RTPG_89: vars=31 stmts=4
enum State { BLUE, RED, GREEN };
void test_func(void) {
    int val81 = 49;
    int res47 = 13;
    int sum19 = 4305;
    int b75 = 43;
    int v28 = 8;
    int sum18 = 22;
    int val46 = 44;
    int cur72 = 6;
    int z43 = 45;
    int x85 = -12;
    int c67 = 62559;
    int c44 = 1;
    int cur91 = 3;
    int res51 = 28180;
    int b18 = 4;
    int tmp3 = 25533;
    int prev62 = 97;
    int sum60 = 43076;
    int hi79 = 83;
    int b35 = 44;
    int res40 = 23879;
    int tmp39 = 61671;
    int v74 = 9;
    int sum39 = 6;
    int lo86 = 30;
    int dat1 = 8;
    int hi22 = -12;
    int c72 = -30;
    int hi48 = 85;
    int sum49 = 84;
    int res95 = 61;
    enum State st = BLUE;
    int i;
    for (i = 0; i < 17; i++) {
        v28 = c67;
        sum39 = hi22;
        sum39 = b18;
        x85 = hi79 - cur91;
    }
}
int main() { test_func(); return 0; }

