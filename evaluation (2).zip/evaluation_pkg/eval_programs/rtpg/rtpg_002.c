// RTPG_2: vars=45 stmts=8
int idx_arr[16];
struct Point { int a; int b; };
void test_func(void) {
    int lo70 = -30;
    int sum54 = 30829;
    int tmp9 = 1;
    int a6 = 75;
    int out1 = 35;
    int cnt62 = 39322;
    int hi27 = 1221;
    int lo17 = 22;
    int y86 = 8;
    int tmp21 = 20677;
    int cnt23 = 39;
    int out16 = 10;
    int acc7 = 71;
    int hi64 = 27;
    int v12 = 34;
    int lo93 = 82;
    int val58 = 43;
    int dat94 = 2;
    int tmp24 = 1;
    int v7 = 19411;
    int a7 = 2;
    int prev7 = 5;
    int v37 = 49;
    int out84 = 3;
    int hi31 = 44;
    int prev93 = 14169;
    int z96 = 26159;
    int dat73 = 5;
    int y29 = 52;
    int y74 = 46026;
    int val85 = 10;
    int x49 = 4;
    int hi19 = 56;
    int acc9 = 15158;
    int z4 = 5818;
    int c48 = 69;
    int res30 = 86;
    int out7 = 93;
    int val59 = 42;
    int cnt45 = 55109;
    int hi52 = 39447;
    int a84 = -50;
    int acc13 = 42238;
    int cnt52 = 28011;
    int v68 = 11;
    struct Point s; s.a = 46; s.b = -32;
    int i;
    for (i = 0; i < 32; i++) {
        val85 = xn[idx_arr[i]];
        cnt45 = y74 - hi52;
        res30 = v68 - 7;
        hi27 = v12 - out16;
        a6 = a6 + 1;
        y74 = y74 - 55934;
        cnt23 = y29 + val58;
        hi52 = acc9;
        x49 = dat94 - 37;
        s.a = s.a + s.b;
    }
}
int main() { test_func(); return 0; }

