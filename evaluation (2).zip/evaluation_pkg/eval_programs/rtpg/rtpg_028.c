// RTPG_28: vars=10 stmts=4
void test_func(void) {
    int dat61 = 6;
    int lo23 = 2;
    int dat86 = 12484;
    int y20 = 32;
    int prev99 = 36;
    int b61 = 28;
    int cur78 = 8;
    int a53 = 31;
    int hi14 = 49629;
    int x87 = 58221;
    int i;
    for (i = 0; i < 61; i++) {
        lo23 = a53 + b61;
        a53 = lo23 - cur78;
        dat61 = dat61 + 1;
        x87 = x87 - 5;
        if (hi14 > 66) {
        b61 = dat61;
        }
    }
}
int main() { test_func(); return 0; }

