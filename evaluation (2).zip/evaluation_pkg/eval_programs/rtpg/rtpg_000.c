// RTPG_0: vars=4 stmts=3
int xn[16];
int yo[16];
void test_func(void) {
    int val19 = 13;
    int acc13 = 9;
    int cnt43 = 71;
    int v97 = 9;
    int i;
    for (i = 0; i < 16; i++) {
        acc13 = xn[i];
        cnt43 = acc13 + v97;
        cnt43 = cnt43 - val19;
        cnt43 = cnt43 + 31;
        if (v97 >= 19) {
        acc13 = val19;
        }
        yo[i] = acc13;
    }
}
int main() { test_func(); return 0; }

