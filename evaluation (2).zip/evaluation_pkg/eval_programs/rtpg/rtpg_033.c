// RTPG_33: vars=45 stmts=3
int idx_arr[32];
void test_func(void) {
    int out47 = 24;
    int z54 = 4;
    int out22 = 1931;
    int out1 = 40839;
    int sum46 = 90;
    int acc2 = 19;
    int dat55 = -41;
    int lo34 = 3;
    int cur61 = -1;
    int lo17 = -25;
    int hi96 = 88;
    int z23 = 2;
    int x98 = 11;
    int b38 = 5;
    int c91 = 3;
    int hi24 = 15683;
    int out29 = -49;
    int b44 = 48;
    int val36 = 7;
    int prev48 = 0;
    int out39 = 30;
    int tmp33 = 2799;
    int a81 = 5;
    int lo69 = 38629;
    int lo80 = 24;
    int res81 = 7;
    int cnt24 = 58;
    int tmp0 = 95;
    int dat76 = -48;
    int z56 = 42;
    int sum60 = 64;
    int x0 = 5;
    int res97 = 1;
    int out55 = 2;
    int tmp66 = 4171;
    int v52 = 10;
    int lo79 = 5;
    int b6 = 10481;
    int cnt37 = 47;
    int b37 = 0;
    int hi38 = 4;
    int val70 = 18;
    int out34 = 23449;
    int cnt33 = 46919;
    int prev31 = 4;
    int i;
    for (i = 0; i < 18; i++) {
        v52 = xn[idx_arr[i]];
        tmp33 = tmp66 - 71;
        hi38 = out39 + cnt37;
        b38 = v52 - out29;
    }
}
int main() { test_func(); return 0; }

