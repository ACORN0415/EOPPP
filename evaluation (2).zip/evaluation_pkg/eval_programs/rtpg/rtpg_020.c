// RTPG_20: vars=4 stmts=8
int idx_arr[16];
void test_func(void) {
    int cnt28 = 5;
    int out91 = 36;
    int cnt92 = 9035;
    int acc31 = 4;
    int *ptr = &acc31;
    int i;
    for (i = 0; i < 77; i++) {
        cnt28 = xn[idx_arr[i]];
        cnt92 = cnt92 - 5;
        out91 = cnt92 % acc31;
        cnt92 = acc31 % cnt28;
        cnt28 = cnt28;
        acc31 = cnt28;
        cnt28 = out91 | acc31;
        out91 = cnt28;
        acc31 = out91 ^ acc31;
        *ptr = *ptr + 1;
    }
done:
    out91 = 0;
}
int main() { test_func(); return 0; }

