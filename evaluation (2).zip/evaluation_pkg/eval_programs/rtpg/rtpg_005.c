// RTPG_5: vars=30 stmts=3
struct Node { int a; int b; };
void test_func(void) {
    int prev61 = 82;
    int hi36 = 10;
    int dat18 = 40493;
    int b31 = 0;
    int a30 = -9;
    int tmp59 = 70;
    int c10 = 62;
    int prev79 = 9;
    int sum86 = 87;
    int cnt88 = 1;
    int prev73 = 34363;
    int val58 = 30648;
    int c21 = 29;
    int sum25 = 82;
    int cur75 = 10;
    int tmp63 = 0;
    int out20 = 50941;
    int prev35 = 35;
    int z56 = 64140;
    int cur73 = -46;
    int dat87 = 7;
    int val85 = 10;
    int sum81 = 16012;
    int tmp77 = 1;
    int sum89 = 5;
    int res52 = -24;
    int sum2 = 19;
    int x59 = -34;
    int y77 = 1;
    int x72 = 5;
    struct Node s; s.a = 16615; s.b = 8331;
    int i;
    for (i = 0; i < 35; i++) {
        int j;
        for (j = 0; j < 19; j++) {
        sum89 = out20;
        z56 = cur75 + cur73;
        hi36 = hi36 - 4;
        }
    }
}
int main() { test_func(); return 0; }

