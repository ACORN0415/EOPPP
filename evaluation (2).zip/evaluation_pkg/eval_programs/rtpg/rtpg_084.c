// RTPG_84: vars=44 stmts=3
void test_func(void) {
    int x63 = 5120;
    int out63 = -29;
    int y41 = 52;
    int cnt39 = 38;
    int hi65 = -3;
    int cur61 = 88;
    int tmp57 = 61881;
    int acc19 = -8;
    int b96 = 61;
    int z48 = 6;
    int a21 = -11;
    int tmp41 = 1;
    int hi66 = 0;
    int z13 = 72;
    int lo90 = 25;
    int cnt89 = 94;
    int hi32 = 48;
    int prev78 = 25;
    int v96 = -28;
    int dat31 = 83;
    int b80 = 36339;
    int tmp73 = -29;
    int a57 = 28;
    int v62 = 7;
    int dat76 = 55759;
    int out91 = -12;
    int prev47 = 50533;
    int sum42 = 5;
    int out62 = -23;
    int tmp7 = 57;
    int z18 = 72;
    int cnt0 = 47;
    int x20 = 25033;
    int tmp48 = -28;
    int acc83 = 7;
    int x50 = 43;
    int out64 = 4;
    int dat13 = 62749;
    int dat97 = 91;
    int out21 = 3989;
    int z12 = 30;
    int val88 = 7;
    int out94 = -47;
    int res95 = 2;
    int i;
    for (i = 0; i < 82; i++) {
        out62 = b80 + acc83;
        prev78 = val88 + 41;
        tmp48 = out94 - prev47;
    }
}
int main() { test_func(); return 0; }

