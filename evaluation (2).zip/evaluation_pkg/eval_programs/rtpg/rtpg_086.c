// RTPG_86: vars=27 stmts=3
void test_func(void) {
    int out99 = 31;
    int tmp97 = 5;
    int v55 = -21;
    int b25 = 0;
    int z44 = 23577;
    int prev68 = 50701;
    int dat3 = -17;
    int cur0 = 13951;
    int c38 = 13292;
    int hi70 = 16875;
    int prev89 = 63720;
    int v60 = 39709;
    int cur12 = 15199;
    int lo0 = 100;
    int b51 = 23441;
    int b40 = 47;
    int z92 = -7;
    int a49 = 59637;
    int hi85 = 0;
    int c30 = 47;
    int sum10 = 4;
    int tmp19 = 23;
    int hi20 = 58;
    int tmp77 = 77;
    int acc36 = 18;
    int prev59 = -40;
    int cnt76 = 64;
    int i;
    for (i = 0; i < 43; i++) {
        v60 = hi20 + c30;
        cnt76 = cnt76 - 1;
        v55 = v60;
        if (tmp97 > -25) {
        cur12 = cur12 + 3;
        }
    }
}
int main() { test_func(); return 0; }

