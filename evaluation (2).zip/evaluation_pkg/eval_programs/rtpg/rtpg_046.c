// RTPG_46: vars=6 stmts=2
int xn[32];
int yo[32];
void test_func(void) {
    int a49 = 6;
    int out43 = 21;
    int y55 = 40955;
    int lo40 = 64298;
    int x97 = 7306;
    int out69 = 76;
    int i;
    for (i = 0; i < 32; i++) {
        y55 = xn[i];
        y55 = a49 + out43;
        y55 = out69;
        yo[i] = x97;
    }
}
int main() { test_func(); return 0; }

