// RTPG_49: vars=10 stmts=4
void test_func(void) {
    int a71 = 30782;
    int val9 = 5;
    int prev87 = 80;
    int lo10 = 6;
    int dat87 = 22265;
    int prev90 = 17;
    int v91 = 8;
    int b41 = 17;
    int x60 = 37;
    int cnt94 = 56;
    int i;
    for (i = 0; i < 100; i++) {
        b41 = x60 - -26;
        b41 = b41 % dat87;
        b41 = b41 - x60;
        b41 = prev87 + prev90;
    }
}
int main() { test_func(); return 0; }

