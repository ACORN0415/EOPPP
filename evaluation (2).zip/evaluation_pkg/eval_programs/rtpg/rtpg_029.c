// RTPG_29: vars=39 stmts=9
int xn[64];
int yo[64];
struct Node { int a; int b; };
void test_func(void) {
    int y70 = 74;
    int b13 = 6;
    int prev84 = -32;
    int res38 = 21;
    int dat64 = -43;
    int v58 = 8;
    int hi65 = 29401;
    int prev43 = 3;
    int b17 = 6;
    int v25 = 26620;
    int v79 = 31;
    int b63 = 3;
    int acc90 = 15644;
    int a32 = 4;
    int cur86 = 33;
    int prev53 = 40;
    int cnt5 = 39473;
    int v24 = 46;
    int b90 = -22;
    int lo58 = 6;
    int sum57 = 28;
    int a97 = 5;
    int out88 = 35;
    int cur71 = 10;
    int tmp35 = 14861;
    int out80 = 4;
    int cnt74 = 58401;
    int sum87 = 84;
    int dat15 = 8;
    int acc64 = 27942;
    int c64 = 1;
    int cnt77 = 4;
    int out40 = -39;
    int acc13 = 10;
    int v91 = 53012;
    int c88 = 5;
    int a50 = 10;
    int x67 = 65;
    int dat22 = 78;
    struct Node s; s.a = 4040; s.b = 17876;
    int h0 = 19;
    int sv0 = 0;
    int h1 = 0;
    int sv1 = 0;
    int h2 = 0;
    int sv2 = 0;
    int h3 = -24;
    int sv3 = 0;
    int i;
    for (i = 0; i < 64; i++) {
        cnt74 = xn[i];
        out40 = v79 + 3;
        a50 = res38 * 83;
        cnt5 = acc90 - a97;
        prev53 = b90 + acc90;
        dat15 = lo58;
        v25 = v25 - 3;
        v79 = sum57 + cur86;
        sum87 = cur71;
        a97 = c64 * 40039;
        s.a = s.a + s.b;
        yo[i] = c88;
    }
}
int main() { test_func(); return 0; }

