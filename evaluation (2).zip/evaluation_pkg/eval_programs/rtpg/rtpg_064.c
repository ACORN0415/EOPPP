// RTPG_64: vars=9 stmts=7
int xn[32];
int yo[32];
void test_func(void) {
    int z42 = 12839;
    int out14 = -2;
    int prev3 = 8;
    int tmp9 = 90;
    int val15 = 7;
    int z46 = 52777;
    int out52 = -34;
    int acc99 = 19;
    int val18 = 42;
    int h0 = 3;
    int sv0 = 0;
    int h1 = 60;
    int sv1 = 0;
    int h2 = 92;
    int sv2 = 0;
    int h3 = 40;
    int sv3 = 0;
    int i;
    for (i = 0; i < 32; i++) {
        out14 = xn[i];
        tmp9 = out14 * 8;
        z42 = val18 - prev3;
        val18 = out52 + tmp9;
        out52 = out52 - 2;
        val18 = val18 + 5;
        val18 = tmp9 * 47;
        out52 = z46 + 32;
        yo[i] = val15;
    }
}
int main() { test_func(); return 0; }

