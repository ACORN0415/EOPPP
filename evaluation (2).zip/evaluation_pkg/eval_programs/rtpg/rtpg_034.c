// RTPG_34: vars=38 stmts=6
int xn[16];
int yo[16];
void test_func(void) {
    int a98 = 52236;
    int y70 = 47;
    int x81 = 0;
    int sum11 = 35;
    int dat27 = 14750;
    int dat64 = 45;
    int c62 = 84;
    int b17 = -6;
    int y86 = 30;
    int dat95 = 2;
    int b41 = 80;
    int dat12 = 89;
    int z99 = 10;
    int tmp32 = 33903;
    int y40 = 2411;
    int z28 = 68;
    int acc44 = 37;
    int val46 = 0;
    int cnt53 = 6;
    int dat48 = -13;
    int z60 = 91;
    int tmp95 = 26;
    int y98 = 3;
    int lo45 = 43722;
    int dat31 = 21;
    int z92 = -5;
    int prev18 = 33775;
    int tmp19 = 21;
    int acc61 = 5;
    int prev6 = 29810;
    int sum4 = 20;
    int prev57 = -8;
    int b43 = -33;
    int sum67 = 17728;
    int cnt37 = 73;
    int out72 = 21;
    int dat51 = 94;
    int res89 = 39;
    int i;
    for (i = 0; i < 7; i++) {
        switch (dat95) {
            case 0: c62 = -27; break;
            case 1: y40 = 3; break;
            default: break;
        }
        dat95 = dat95 + 1;
    }
}
int main() { test_func(); return 0; }

