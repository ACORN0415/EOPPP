// RTPG_4: vars=46 stmts=7
int xn[64];
int yo[64];
void test_func(void) {
    int tmp46 = 69;
    int x63 = -44;
    int cnt62 = 10;
    int v10 = 62747;
    int cur89 = 33093;
    int tmp15 = 1;
    int hi27 = 30;
    int lo34 = 22;
    int hi35 = 21;
    int prev43 = 58;
    int acc31 = 9;
    int dat47 = 3;
    int sum28 = -20;
    int tmp92 = 58;
    int prev88 = 37057;
    int a95 = 37;
    int hi70 = -36;
    int tmp88 = -32;
    int c38 = 37829;
    int cnt95 = 39858;
    int sum12 = 64723;
    int x11 = 6;
    int out97 = -18;
    int lo31 = 76;
    int v37 = 22963;
    int res44 = 33;
    int dat34 = 9;
    int hi59 = 53;
    int acc23 = 43229;
    int res76 = 7;
    int x66 = 41;
    int cnt93 = 151;
    int lo72 = 47420;
    int c24 = 6;
    int val71 = 37753;
    int acc35 = -35;
    int tmp39 = 4;
    int v40 = -36;
    int out42 = 35839;
    int hi82 = 10;
    int dat97 = 6;
    int hi57 = 54;
    int sum32 = 39133;
    int v94 = 69;
    int cur33 = 49442;
    int z35 = 31301;
    int i;
    for (i = 0; i < 64; i++) {
        prev88 = xn[i];
        dat34 = sum12 - z35;
        v37 = sum32 + hi57;
        cnt93 = hi35 - hi27;
        acc23 = c24 - tmp46;
        prev43 = hi57 + prev43;
        x66 = x11;
        hi82 = hi57 - tmp15;
        yo[i] = v94;
    }
}
int main() { test_func(); return 0; }

