// RTPG_53: vars=8 stmts=5
void test_func(void) {
    int prev57 = 11;
    int res78 = 93;
    int x35 = 66;
    int v69 = 3;
    int prev99 = 3;
    int cur83 = 0;
    int lo89 = 16352;
    int b89 = 684;
    int i;
    for (i = 0; i < 9; i++) {
        cur83 = v69 - 18347;
        v69 = cur83 + cur83;
        b89 = x35 - lo89;
        res78 = prev57 - x35;
        b89 = b89 + 52790;
        if (prev99 == 77) {
        lo89 = b89 - cur83;
        }
    }
}
int main() { test_func(); return 0; }

