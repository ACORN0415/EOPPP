// RTPG_44: vars=18 stmts=9
int idx_arr[16];
void test_func(void) {
    int lo79 = 7;
    int b63 = -26;
    int c35 = 43;
    int z50 = 63721;
    int z24 = 73;
    int out37 = 30;
    int out16 = 7;
    int cur86 = 22;
    int z13 = -28;
    int a89 = -36;
    int b26 = -17;
    int res80 = 5;
    int hi90 = 58;
    int c36 = -47;
    int out86 = 20;
    int cnt87 = 38;
    int lo11 = 19;
    int x37 = 43;
    int i;
    for (i = 0; i < 99; i++) {
        x37 = xn[idx_arr[i]];
        z50 = lo79;
        hi90 = hi90 + 4;
        res80 = b26 + out16;
        lo11 = z13 + 0;
        lo11 = out16 - cnt87;
        lo11 = res80 - z24;
        c36 = hi90;
        res80 = a89 - res80;
        a89 = x37 + c35;
        if (out86 != 56) {
        out86 = out37;
        }
    }
}
int main() { test_func(); return 0; }

