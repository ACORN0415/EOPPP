// RTPG_85: vars=14 stmts=4
void test_func(void) {
    int z92 = -10;
    int v95 = 23;
    int y48 = 12;
    int c1 = -4;
    int tmp39 = 24;
    int sum22 = -6;
    int cur58 = 5;
    int z23 = 48;
    int x98 = -17;
    int v81 = 60;
    int val17 = 85;
    int b39 = 30;
    int z14 = 6;
    int acc75 = 21332;
    int i;
    for (i = 0; i < 15; i++) {
        z14 = z23 - v81;
        cur58 = z23 - c1;
        v81 = z23;
        tmp39 = c1 + cur58;
    }
}
int main() { test_func(); return 0; }

