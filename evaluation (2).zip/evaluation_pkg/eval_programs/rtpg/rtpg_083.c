// RTPG_83: vars=14 stmts=4
void test_func(void) {
    int hi62 = -47;
    int tmp14 = 72;
    int sum53 = 51299;
    int tmp84 = 34;
    int sum12 = 7;
    int a44 = 7;
    int prev90 = 100;
    int cnt14 = 2;
    int b99 = 100;
    int c59 = -42;
    int acc84 = 20578;
    int cnt87 = 21;
    int lo41 = 6;
    int out61 = 13438;
    int i;
    for (i = 0; i < 9; i++) {
        lo41 = hi62 - sum53;
        sum12 = tmp84 + hi62;
        sum12 = out61 - acc84;
        prev90 = out61 - 1;
    }
}
int main() { test_func(); return 0; }

