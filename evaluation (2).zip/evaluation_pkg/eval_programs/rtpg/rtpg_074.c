// RTPG_74: vars=6 stmts=3
void test_func(void) {
    int prev57 = 10;
    int sum73 = -20;
    int prev24 = 61;
    int cnt21 = 71;
    int res25 = 52027;
    int z35 = 7;
    int h0 = 50138;
    int sv0 = 0;
    int h1 = -13;
    int sv1 = 0;
    int h2 = 64700;
    int sv2 = 0;
    int i;
    for (i = 0; i < 64; i++) {
        prev57 = prev57 % z35;
        prev24 = prev57 & prev57;
        sum73 = res25 ^ prev57;
        if (res25 != 53) {
        cnt21 = prev57 - sum73;
        }
    }
}
int main() { test_func(); return 0; }

