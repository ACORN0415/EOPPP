// RTPG_68: vars=25 stmts=10
void test_func(void) {
    int cnt19 = -32;
    double cur10 = 35.26;
    int sum44 = 38;
    int z78 = 54875;
    int sum45 = 30162;
    double lo92 = 52.69;
    int tmp13 = 12;
    float b49 = 36.24;
    int a34 = 8;
    int acc76 = 18893;
    float hi8 = 5.59;
    float b40 = 37.75;
    double a62 = 37.17;
    int c86 = 24;
    double acc15 = 14.13;
    float a73 = 56.92;
    int cnt67 = 47;
    int z0 = 44216;
    int hi84 = 0;
    int c14 = 27;
    double b22 = 67.99;
    int b99 = 41;
    int y77 = -16;
    int sum79 = 28693;
    float cur33 = 81.66;
    int i;
    for (i = 0; i < 20; i++) {
        switch (acc15) {
            case 0: hi8 = 32; break;
            case 1: cur10 = 55; break;
            case 2: z78 = 1; break;
            default: break;
        }
        acc15 = acc15 + 1;
    }
}
int main() { test_func(); return 0; }

