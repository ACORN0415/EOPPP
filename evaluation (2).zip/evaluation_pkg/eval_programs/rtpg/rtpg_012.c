// RTPG_12: vars=5 stmts=3
void test_func(void) {
    int res44 = 31;
    int z57 = 14;
    int b99 = -29;
    int lo87 = 37;
    int b40 = 31;
    int i;
    for (i = 0; i < 35; i++) {
        b40 = b40 + 5;
        b40 = b40 + 2;
        b40 = b40;
        if (res44 < -30) {
        res44 = res44 - 2;
        }
    }
}
int main() { test_func(); return 0; }

