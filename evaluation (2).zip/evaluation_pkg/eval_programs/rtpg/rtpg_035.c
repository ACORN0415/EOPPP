// RTPG_35: vars=18 stmts=12
int xn[32];
int yo[32];
void test_func(void) {
    int out67 = 37476;
    int lo5 = 4;
    int acc58 = 7;
    int dat76 = 17735;
    int a57 = -9;
    int out50 = 26468;
    int prev99 = 1;
    int y71 = 91;
    int tmp54 = 17;
    int prev66 = 20;
    int sum56 = 22;
    int acc50 = 6726;
    int prev92 = 94;
    int y77 = -27;
    int y24 = 0;
    int tmp66 = 754;
    int hi88 = 62353;
    int y66 = 6;
    int i;
    for (i = 0; i < 32; i++) {
        y66 = xn[i];
        tmp54 = tmp54 + 1;
        out50 = lo5 - 5;
        acc58 = dat76 - out50;
        out50 = y66;
        out50 = acc50 + lo5;
        prev66 = acc50;
        prev92 = y77 + prev66;
        tmp66 = dat76 - 17;
        lo5 = hi88 + tmp66;
        prev66 = sum56 - tmp54;
        a57 = a57 - 5;
        tmp66 = out50 - y71;
        if (prev99 < -20) {
        out67 = dat76 - prev99;
        }
        yo[i] = y77;
    }
}
int main() { test_func(); return 0; }

