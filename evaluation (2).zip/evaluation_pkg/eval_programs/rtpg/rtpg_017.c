// RTPG_17: vars=9 stmts=3
void test_func(void) {
    int v61 = 1;
    int tmp41 = 27;
    int prev46 = 2;
    int prev35 = -12;
    int sum41 = 58861;
    int acc22 = 9;
    int sum94 = 5;
    int prev40 = 34;
    int hi73 = 6;
    int h0 = -49;
    int sv0 = 0;
    int h1 = 28972;
    int sv1 = 0;
    int h2 = 60;
    int sv2 = 0;
    int i;
    for (i = 0; i < 97; i++) {
        prev40 = sum41 - tmp41;
        prev46 = acc22 * 27115;
        tmp41 = prev40 + acc22;
        if (sum41 < -21) {
        v61 = tmp41;
        }
    }
}
int main() { test_func(); return 0; }

