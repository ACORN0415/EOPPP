// RTPG_26: vars=4 stmts=4
struct Point { int a; int b; };
void test_func(void) {
    int res15 = 18;
    int hi24 = 59;
    int prev67 = 11;
    int sum52 = 10;
    struct Point s; s.a = -15; s.b = 50;
    int h0 = 56234;
    int sv0 = 0;
    int h1 = 5;
    int sv1 = 0;
    int i;
    for (i = 0; i < 92; i++) {
        prev67 = prev67 + 1;
        hi24 = prev67 - -37;
        res15 = prev67 * 44281;
        hi24 = sum52;
        s.a = s.a + s.b;
        if (prev67 > -8) {
        sum52 = hi24 + hi24;
        }
    }
}
int main() { test_func(); return 0; }

