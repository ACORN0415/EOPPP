// RTPG_40: vars=40 stmts=2
void test_func(void) {
    int y48 = 18858;
    int lo44 = 13927;
    int acc32 = 4;
    int out1 = 9;
    int tmp93 = 7;
    int c32 = 35;
    int tmp92 = 64315;
    int acc86 = 1;
    int b48 = 0;
    int a90 = 46;
    int c99 = 81;
    int cnt88 = 11;
    int x79 = 5156;
    int sum59 = 10;
    int prev22 = 10;
    int dat23 = 6;
    int hi25 = 31259;
    int x8 = 40335;
    int v76 = 3;
    int z81 = 5612;
    int dat50 = -23;
    int z7 = -21;
    int val22 = 7;
    int prev42 = 3;
    int v4 = 2;
    int a67 = 7;
    int dat98 = 1;
    int a11 = 44;
    int c40 = 74;
    int a87 = 6;
    int x52 = 18513;
    int y33 = 21628;
    int a89 = 3;
    int lo35 = 10;
    int lo98 = -40;
    int sum32 = 37190;
    int val83 = 38;
    int v66 = 59038;
    int lo8 = -28;
    int z35 = 12;
    int i;
    for (i = 0; i < 41; i++) {
        int j;
        for (j = 0; j < 18; j++) {
        y48 = y48 + 2;
        acc86 = acc86 + 5;
        }
    }
}
int main() { test_func(); return 0; }

