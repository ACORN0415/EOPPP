// RTPG_62: vars=9 stmts=4
void test_func(void) {
    int tmp89 = 55370;
    int v93 = 5;
    int prev38 = 43;
    int c62 = 13;
    int c2 = 39856;
    int acc19 = 18031;
    int hi37 = -13;
    int y99 = 84;
    int prev7 = 19347;
    int i;
    for (i = 0; i < 33; i++) {
        hi37 = tmp89 + 5;
        prev7 = hi37;
        prev38 = c62 + tmp89;
        c62 = y99 + c2;
        if (hi37 != -28) {
        y99 = c2 - y99;
        }
    }
}
int main() { test_func(); return 0; }

