// RTPG_76: vars=6 stmts=4
void test_func(void) {
    int cur59 = 7;
    int cur54 = 8;
    int prev55 = 39;
    int acc64 = 2;
    int res56 = 781;
    int a17 = 8;
    int i;
    for (i = 0; i < 43; i++) {
        res56 = a17 ^ cur59;
        a17 = prev55 | res56;
        cur59 = a17 + a17;
        cur54 = cur54 | res56;
    }
}
int main() { test_func(); return 0; }

