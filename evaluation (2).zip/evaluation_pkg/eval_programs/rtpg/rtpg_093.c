// RTPG_93: vars=7 stmts=3
void test_func(void) {
    int lo5 = -19;
    double dat10 = 24.37;
    double val3 = 83.79;
    int b85 = 22;
    int acc28 = 81;
    int hi28 = 56;
    int tmp70 = 3;
    int i;
    for (i = 0; i < 30; i++) {
        hi28 = val3 + 12665;
        acc28 = lo5;
        tmp70 = tmp70 + 3;
    }
}
int main() { test_func(); return 0; }

