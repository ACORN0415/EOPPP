// RTPG_38: vars=8 stmts=2
void test_func(void) {
    int a36 = 56;
    int b37 = 1;
    int dat1 = -28;
    int x90 = -1;
    int out45 = 4;
    int y47 = 18874;
    int res51 = 5;
    int out6 = 3;
    int i;
    for (i = 0; i < 23; i++) {
        out6 = out6 - 5;
        out6 = y47 + b37;
    }
}
int main() { test_func(); return 0; }

