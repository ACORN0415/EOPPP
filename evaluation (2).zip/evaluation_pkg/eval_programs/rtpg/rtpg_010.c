// RTPG_10: vars=6 stmts=6
int xn[32];
int yo[32];
void test_func(void) {
    int hi47 = 24;
    int acc23 = 42;
    int z93 = 27;
    int cnt10 = 58;
    int res34 = 9;
    int hi88 = 31;
    int i;
    for (i = 0; i < 32; i++) {
        hi47 = xn[i];
        acc23 = acc23 - 1;
        acc23 = acc23 - z93;
        cnt10 = cnt10 + 5;
        acc23 = z93 - hi88;
        hi47 = hi47 + 5;
        z93 = z93 + hi88;
        yo[i] = hi47;
    }
}
int main() { test_func(); return 0; }

