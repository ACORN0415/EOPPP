// RTPG_87: vars=7 stmts=6
int xn[32];
int yo[32];
void test_func(void) {
    int c35 = 54;
    int prev23 = 4;
    int val95 = -22;
    int x52 = 60378;
    int sum34 = 50993;
    int y77 = 44;
    int res85 = 60549;
    int i;
    for (i = 0; i < 32; i++) {
        prev23 = xn[i];
        sum34 = y77 - 10304;
        sum34 = c35;
        prev23 = prev23 - 3;
        val95 = x52;
        y77 = c35 + prev23;
        sum34 = sum34;
        yo[i] = x52;
    }
}
int main() { test_func(); return 0; }

