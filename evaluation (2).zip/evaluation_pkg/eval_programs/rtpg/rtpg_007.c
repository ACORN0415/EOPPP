// RTPG_7: vars=32 stmts=5
int xn[64];
int yo[64];
void test_func(void) {
    int c34 = 28;
    int res27 = 1014;
    int cnt62 = -28;
    int dat84 = 8;
    int cur55 = 6;
    int y86 = 56268;
    int cur0 = 15097;
    int res85 = 22;
    int val27 = 31892;
    int lo84 = 10309;
    int a36 = 44;
    int y0 = -41;
    int res14 = -6;
    int prev8 = -32;
    int val3 = -31;
    int prev53 = 60;
    int c18 = 10;
    int x11 = 81;
    int sum43 = 46;
    int c47 = 5;
    int b94 = 11836;
    int dat76 = 5377;
    int b20 = 42144;
    int lo53 = 8;
    int sum5 = 5;
    int z34 = 40;
    int tmp50 = 50780;
    int z6 = 77;
    int sum92 = 13;
    int dat62 = 85;
    int lo43 = 85;
    int acc99 = 33;
    int i;
    for (i = 0; i < 64; i++) {
        y86 = xn[i];
        c47 = c47 - 3;
        val27 = val27 + 4;
        lo53 = lo53 - y0;
        prev8 = acc99;
        res14 = val27 + 13;
        if (val27 == 46) {
        lo84 = y0 + -45;
        }
        yo[i] = sum92;
    }
}
int main() { test_func(); return 0; }

