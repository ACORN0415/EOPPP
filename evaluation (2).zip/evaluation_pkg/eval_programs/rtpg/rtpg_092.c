// RTPG_92: vars=55 stmts=2
void test_func(void) {
    int dat61 = 53171;
    int c46 = 34447;
    int hi95 = 36;
    int dat66 = 63879;
    int res21 = 86;
    int hi60 = 1;
    int x63 = 29770;
    int res73 = -35;
    int out46 = 5;
    int c50 = -27;
    int b74 = -22;
    int a20 = 5;
    int acc84 = -4;
    int b41 = -30;
    int x42 = 19;
    int x39 = 38863;
    int tmp32 = 61;
    int res16 = 2;
    int b52 = 40;
    int c1 = 7763;
    int b77 = -32;
    int a91 = 54921;
    int b28 = 9;
    int prev80 = 3;
    int prev36 = 26979;
    int b81 = 2;
    int v39 = 10;
    int y30 = 30433;
    int acc1 = -35;
    int prev97 = 93;
    int tmp11 = 14790;
    int cnt47 = 22;
    int a60 = 14;
    int z95 = 56686;
    int c93 = 14;
    int sum42 = 43101;
    int val97 = 10;
    int y94 = 31817;
    int c12 = 3;
    int y25 = 49260;
    int hi44 = 0;
    int out56 = 47278;
    int a31 = 96;
    int lo53 = 10;
    int x60 = 6;
    int val16 = 24;
    int dat25 = 3720;
    int acc3 = 88;
    int y69 = 58;
    int lo85 = 39;
    int a61 = 42190;
    int x44 = 5;
    int cnt8 = 79;
    int y95 = 11854;
    int cur33 = 24405;
    int i;
    for (i = 0; i < 21; i++) {
        b28 = cur33 | val16;
        acc1 = y69;
        if (b74 > 32) {
        c46 = acc84 - a60;
        }
    }
}
int main() { test_func(); return 0; }

