// RTPG_32: vars=8 stmts=3
int xn[64];
int yo[64];
void test_func(void) {
    int b94 = 41384;
    int b60 = 6254;
    int b73 = 38;
    int tmp12 = 12623;
    int x22 = 47;
    int out55 = 53;
    int val30 = 26;
    int prev25 = 63897;
    int h0 = 28;
    int sv0 = 0;
    int h1 = 55289;
    int sv1 = 0;
    int i;
    for (i = 0; i < 64; i++) {
        b60 = xn[i];
        out55 = tmp12 * 84;
        val30 = prev25;
        out55 = out55 - 4;
        if (b73 > -45) {
        b73 = x22 + 3;
        }
        yo[i] = b60;
    }
}
int main() { test_func(); return 0; }

