// RTPG_82: vars=3 stmts=7
int xn[64];
int yo[64];
void test_func(void) {
    int out24 = 12;
    int y69 = 23;
    int c3 = 15721;
    int i;
    for (i = 0; i < 64; i++) {
        y69 = xn[i];
        out24 = y69 + 5;
        c3 = y69;
        c3 = c3 + 3;
        out24 = out24 + y69;
        c3 = c3 + out24;
        y69 = y69 % out24;
        y69 = c3 - -34;
        yo[i] = out24;
    }
}
int main() { test_func(); return 0; }

