// RTPG_66: vars=13 stmts=2
void test_func(void) {
    int cur30 = 2;
    int sum14 = 25288;
    int cur94 = 70;
    int val26 = 7;
    int out98 = 54;
    int z13 = 15392;
    int dat67 = 11;
    int b42 = 90;
    int x87 = 24929;
    int dat49 = 37;
    int a85 = 50352;
    int cur95 = 27;
    int cur42 = 0;
    int i;
    for (i = 0; i < 39; i++) {
        switch (cur42) {
            case 0: b42 = 93; break;
            case 1: val26 = 40; break;
            case 2: val26 = 0; break;
            case 3: a85 = 2; break;
            default: break;
        }
        cur42 = cur42 + 1;
    }
}
int main() { test_func(); return 0; }

