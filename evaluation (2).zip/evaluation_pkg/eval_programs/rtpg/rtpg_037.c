// RTPG_37: vars=6 stmts=7
void test_func(void) {
    int prev6 = 91;
    int z54 = 10296;
    int y16 = 9;
    int y13 = 61001;
    int out56 = 19;
    int x60 = 90;
    int h0 = 7;
    int sv0 = 0;
    int h1 = 60;
    int sv1 = 0;
    int h2 = 5;
    int sv2 = 0;
    int i;
    for (i = 0; i < 20; i++) {
        prev6 = out56;
        out56 = y13 - out56;
        y13 = z54 % out56;
        x60 = x60 - 4;
        x60 = z54 + 15;
        z54 = y13;
        y13 = prev6 & x60;
    }
}
int main() { test_func(); return 0; }

