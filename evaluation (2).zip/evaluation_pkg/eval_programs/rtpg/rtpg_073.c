// RTPG_73: vars=24 stmts=4
int xn[32];
int yo[32];
void test_func(void) {
    int val40 = 89;
    int tmp9 = 9;
    int acc54 = -42;
    int hi55 = 8;
    int sum77 = 54;
    int c26 = 6510;
    int res45 = 7;
    int a77 = 42845;
    int z57 = 3;
    int prev54 = 610;
    int v84 = 4;
    int cur47 = 9104;
    int res32 = 93;
    int v72 = 5;
    int dat39 = 8;
    int dat52 = 59583;
    int acc15 = 10;
    int c45 = 3;
    int prev3 = 38;
    int c4 = 2;
    int lo54 = 0;
    int a74 = 43166;
    int b99 = 18057;
    int a23 = 19399;
    int i;
    for (i = 0; i < 32; i++) {
        lo54 = xn[i];
        dat39 = acc15 + prev3;
        dat52 = z57 - v84;
        a77 = z57 - b99;
        acc54 = c45;
        yo[i] = a77;
    }
}
int main() { test_func(); return 0; }

