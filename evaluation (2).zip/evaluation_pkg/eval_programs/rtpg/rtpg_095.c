// RTPG_95: vars=32 stmts=4
void test_func(void) {
    int res21 = 79;
    int acc58 = 7;
    int res11 = 25;
    int v36 = 74;
    int out49 = 4;
    int cur18 = 6873;
    int cnt51 = 8;
    int v77 = -38;
    int out66 = 26688;
    int acc31 = 3;
    int b78 = 89;
    int dat12 = -20;
    int acc17 = 6;
    int x62 = 77;
    int c75 = 37;
    int out8 = 10;
    int acc67 = 2;
    int a41 = 1368;
    int out82 = 39;
    int a63 = 10;
    int cur87 = -30;
    int v37 = 33620;
    int lo14 = 37;
    int v51 = 47;
    int y45 = 21;
    int dat73 = 8;
    int y61 = -21;
    int z62 = 47;
    int prev96 = 28;
    int cnt48 = 26;
    int tmp62 = 3;
    int lo97 = 33;
    int i;
    for (i = 0; i < 78; i++) {
        cnt48 = v36 - -31;
        dat12 = v37 - 9;
        b78 = cur87 + 1;
        b78 = v51;
    }
}
int main() { test_func(); return 0; }

