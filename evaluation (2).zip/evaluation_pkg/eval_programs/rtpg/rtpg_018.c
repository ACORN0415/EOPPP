// RTPG_18: vars=25 stmts=6
void test_func(void) {
    int b73 = 12;
    int v58 = 80;
    int c62 = 25576;
    int a44 = 64877;
    int a30 = 58177;
    int prev54 = -40;
    int sum14 = 36;
    int hi67 = 2;
    int prev53 = 9;
    int cur58 = 7;
    int acc76 = 10;
    int prev78 = 11402;
    int cur41 = 31;
    int b40 = 30;
    int c47 = 8;
    int b65 = 22;
    int a33 = 23;
    int c86 = -43;
    int out88 = -32;
    int out23 = 63;
    int sum78 = 10;
    int dat10 = 12;
    int dat13 = 5;
    int c71 = 1;
    int prev75 = 0;
    int i;
    for (i = 0; i < 59; i++) {
        switch (b65) {
            case 0: acc76 = 17118; break;
            case 1: acc76 = 10; break;
            case 2: sum78 = 20708; break;
            default: break;
        }
        b65 = b65 + 1;
    }
}
int main() { test_func(); return 0; }

